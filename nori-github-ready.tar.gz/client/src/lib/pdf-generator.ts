import { CareEntry, Resident, User } from '@shared/schema';

export function generatePDF(entry: CareEntry, resident: Resident, approver: User): void {
  // For demo purposes, we'll create a simple text representation
  // In a real application, you would use a library like jsPDF or puppeteer
  
  const content = `
Nori – Pflegebericht

Bewohner: ${resident.name}
Zimmer: ${resident.room}
Geburtsdatum: ${resident.dateOfBirth}

Datum: ${new Date(entry.createdAt).toLocaleDateString('de-DE')}
Erstellt von: ${entry.authorId}

${entry.status === 'draft' ? '*** KI-Entwurf – von Pflegekraft geprüft ***' : ''}

VITALWERTE:
${entry.content?.vitalSigns ? Object.entries(entry.content.vitalSigns)
  .filter(([_, value]) => value)
  .map(([key, value]) => `${key}: ${value}`)
  .join('\n') : 'Keine Angaben'}

MEDIKATION:
${entry.content?.medication ? entry.content.medication
  .map(med => `${med.name} ${med.dosage} um ${med.time} - ${med.administered ? 'verabreicht' : 'nicht verabreicht'}`)
  .join('\n') : 'Keine Angaben'}

MOBILITÄT:
${entry.content?.mobility || 'Keine Angaben'}

ERNÄHRUNG/FLÜSSIGKEIT:
${entry.content?.nutrition || 'Keine Angaben'}

HYGIENE:
${entry.content?.hygiene || 'Keine Angaben'}

STIMMUNG/KOGNITION:
${entry.content?.mood || 'Keine Angaben'}

BESONDERHEITEN:
${entry.content?.specialNotes || 'Keine Angaben'}

EMPFEHLUNGEN:
${entry.content?.recommendations || 'Keine Angaben'}

${entry.comments ? `\nKOMMENTAR:\n${entry.comments}` : ''}

Freigegeben am ${entry.approvedAt ? new Date(entry.approvedAt).toLocaleString('de-DE') : ''} von ${approver.name}
  `.trim();

  // Create a blob and download
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `Nori_Pflegebericht_${resident.name}_${new Date(entry.createdAt).toLocaleDateString('de-DE')}.txt`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
